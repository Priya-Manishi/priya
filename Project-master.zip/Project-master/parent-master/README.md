MyBatis Parent
==============

[![Build Status](https://travis-ci.org/mybatis/parent.svg?branch=master)](https://travis-ci.org/mybatis/parent)
[![Dependency Status](https://www.versioneye.com/user/projects/55ff649c601dd9001f0001b5/badge.svg?style=flat)](https://www.versioneye.com/user/projects/55ff649c601dd9001f0001b5)
[![Maven central](https://maven-badges.herokuapp.com/maven-central/org.mybatis/mybatis-parent/badge.svg)](https://maven-badges.herokuapp.com/maven-central/org.mybatis/mybatis-parent)
[![Apache 2](http://img.shields.io/badge/license-Apache%202-red.svg)](http://www.apache.org/licenses/LICENSE-2.0)

![mybatis-parent](http://mybatis.github.io/images/mybatis-logo.png)

MyBatis-Parent is the MyBatis parent POM which has to be inherited by all MyBatis modules.


